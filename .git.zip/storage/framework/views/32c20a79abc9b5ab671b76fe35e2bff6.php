<nav class="navbar default-layout-navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
<div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-start">
    <!-- Logo Teks "Sasalero" -->
    <a class="navbar-brand brand-logo" href="<?php echo e(url('/dashboard')); ?>" style="font-size: 24px; font-weight: bold; color: #4caf50;">
        Sasalero
    </a>
    <a class="navbar-brand brand-logo-mini" href="<?php echo e(url('/dashboard')); ?>" style="font-size: 18px; font-weight: bold; color: #4caf50;">
        Sasalero
    </a>
</div>

  <div class="navbar-menu-wrapper d-flex align-items-stretch">
    <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
      <span class="mdi mdi-menu"></span>
    </button>
    <ul class="navbar-nav navbar-nav-right">
      <li class="nav-item d-none d-lg-block full-screen-link">
        <a class="nav-link">
          <i class="mdi mdi-fullscreen" id="fullscreen-button"></i>
        </a>
      </li>
      <li class="nav-item nav-settings d-none d-lg-block">
        <a class="nav-link" href="#">
          <i class="mdi mdi-format-line-spacing"></i>
        </a>
      </li>
    </ul>
    <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
      <span class="mdi mdi-menu"></span>
    </button>
  </div>
</nav><?php /**PATH C:\laragon\www\sasalero-s\resources\views/layouts/main.blade.php ENDPATH**/ ?>