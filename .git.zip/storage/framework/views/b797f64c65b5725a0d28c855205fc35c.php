

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="mb-4">Dashboard</h2>

    
    <form method="GET" action="<?php echo e(route('dashboard')); ?>" class="mb-3 d-flex gap-2">
        <select name="filter" id="filter" onchange="toggleRange()" class="form-select" style="width:auto;">
            <option value="daily" <?php echo e($filter=='daily'?'selected':''); ?>>Hari Ini</option>
            <option value="monthly" <?php echo e($filter=='monthly'?'selected':''); ?>>Bulanan</option>
            <option value="yearly" <?php echo e($filter=='yearly'?'selected':''); ?>>Tahunan</option>
            <option value="range" <?php echo e($filter=='range'?'selected':''); ?>>Custom Range</option>
        </select>

        <input type="date" name="start_date" id="start_date" value="<?php echo e($start? \Carbon\Carbon::parse($start)->toDateString():''); ?>" class="form-control" style="width:auto; display: <?php echo e($filter=='range'?'block':'none'); ?>">
        <input type="date" name="end_date" id="end_date" value="<?php echo e($end? \Carbon\Carbon::parse($end)->toDateString():''); ?>" class="form-control" style="width:auto; display: <?php echo e($filter=='range'?'block':'none'); ?>">

        <button type="submit" class="btn btn-primary">Terapkan</button>
    </form>

    
    <div class="row mb-4">
        <div class="col-md-4">
            <div class="card text-bg-primary">
                <div class="card-body">
                    <h5>Total Penjualan</h5>
                    <h3>Rp <?php echo e(number_format($totalPenjualan, 0, ',', '.')); ?></h3>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card text-bg-danger">
                <div class="card-body">
                    <h5>Total Pengeluaran</h5>
                    <h3>Rp <?php echo e(number_format($totalPengeluaran, 0, ',', '.')); ?></h3>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card text-bg-success">
                <div class="card-body">
                    <h5>Pendapatan Bersih</h5>
                    <h3>Rp <?php echo e(number_format($pendapatan, 0, ',', '.')); ?></h3>
                </div>
            </div>
        </div>
    </div>

    
    <div class="card">
        <div class="card-body">
            <h5>Grafik Penjualan, Pengeluaran, Pendapatan</h5>
            <canvas id="salesChart"></canvas>
        </div>
    </div>

    
<div class="card mt-4">
    <div class="card-header">Detail Transaksi</div>
    <div class="card-body">
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>Tanggal</th>
                    <th>No Struk</th>
                    <th>Total</th>
                    <th>Uang Dibayar</th>
                    <th>Kembalian</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e(\Carbon\Carbon::parse($trx->tanggal_transaksi)->format('d/m/Y H:i')); ?></td>
                        <td><?php echo e($trx->nomor_struk); ?></td>
                        <td>Rp <?php echo e(number_format($trx->total, 0, ',', '.')); ?></td>
                        <td>Rp <?php echo e(number_format($trx->uang_dibayar, 0, ',', '.')); ?></td>
                        <td>Rp <?php echo e(number_format($trx->kembalian, 0, ',', '.')); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="text-center">Belum ada transaksi</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>


<div class="card mt-4">
    <div class="card-header">Detail Pengeluaran</div>
    <div class="card-body">
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>Tanggal</th>
                    <th>Keterangan</th>
                    <th>Jumlah</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e(\Carbon\Carbon::parse($exp->tanggal)->format('d/m/Y')); ?></td>
                        <td><?php echo e($exp->keterangan); ?></td>
                        <td>Rp <?php echo e(number_format($exp->jumlah, 0, ',', '.')); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="3" class="text-center">Belum ada pengeluaran</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    function toggleRange() {
        const filter = document.getElementById('filter').value;
        document.getElementById('start_date').style.display = (filter === 'range') ? 'block' : 'none';
        document.getElementById('end_date').style.display = (filter === 'range') ? 'block' : 'none';
    }

    const chartData = <?php echo json_encode($chartData, 15, 512) ?>;

    const labels = chartData.map(d => d.tanggal);
    const penjualan = chartData.map(d => d.penjualan);
    const pengeluaran = chartData.map(d => d.pengeluaran);
    const pendapatan = chartData.map(d => d.pendapatan);

    const ctx = document.getElementById('salesChart').getContext('2d');
    const salesChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [
                {
                    label: 'Penjualan',
                    data: penjualan,
                    borderColor: 'blue',
                    backgroundColor: 'rgba(0, 123, 255, 0.2)',
                    tension: 0.3
                },
                {
                    label: 'Pengeluaran',
                    data: pengeluaran,
                    borderColor: 'red',
                    backgroundColor: 'rgba(255, 0, 0, 0.2)',
                    tension: 0.3
                },
                {
                    label: 'Pendapatan',
                    data: pendapatan,
                    borderColor: 'green',
                    backgroundColor: 'rgba(0, 255, 0, 0.2)',
                    tension: 0.3
                }
            ]
        }
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\sasalero-s\resources\views/dashboard/index.blade.php ENDPATH**/ ?>