

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Detail Transaksi</h2>

    <p><strong>Nomor Struk:</strong> <?php echo e($transaction->nomor_struk); ?></p>
    <p><strong>Tanggal:</strong> <?php echo e(\Carbon\Carbon::parse($transaction->tanggal_transaksi)->format('d/m/Y H:i')); ?></p>
    <p><strong>Total:</strong> Rp<?php echo e(number_format($transaction->total,0,',','.')); ?></p>
    <p><strong>Uang Dibayar:</strong> Rp<?php echo e(number_format($transaction->uang_dibayar,0,',','.')); ?></p>
    <p><strong>Kembalian:</strong> Rp<?php echo e(number_format($transaction->kembalian,0,',','.')); ?></p>

    <h4>Barang Dibeli</h4>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Produk</th>
                <th>Qty</th>
                <th>Harga</th>
                <th>Subtotal</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $transaction->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->product->nama); ?></td>
                <td><?php echo e($item->qty); ?></td>
                <td>Rp<?php echo e(number_format($item->harga,0,',','.')); ?></td>
                <td>Rp<?php echo e(number_format($item->subtotal,0,',','.')); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <a href="<?php echo e(route('transactions.index')); ?>" class="btn btn-secondary">Kembali</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\sasalero-s\resources\views/transactions/show.blade.php ENDPATH**/ ?>