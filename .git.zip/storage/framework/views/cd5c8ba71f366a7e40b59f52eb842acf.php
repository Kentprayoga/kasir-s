

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800">Stok Toko</h1>

    
    <div class="card mb-4">
        <div class="card-header">Tambah Stok Toko</div>
        <div class="card-body">
            <form action="<?php echo e(route('stok-toko.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-row">
                    <div class="form-group col-md-5">
                        <label>Produk</label>
                        <select name="product_id" class="form-control" required>
                            <option value="">-- Pilih Produk --</option>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($p->id); ?>"><?php echo e($p->nama_barang); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group col-md-3">
                        <label>Stok Masuk</label>
                        <input type="number" name="stok_masuk" class="form-control" required>
                    </div>
                    <div class="form-group col-md-3">
                        <label>Keterangan</label>
                        <input type="text" name="keterangan" class="form-control">
                    </div>
                    <div class="form-group col-md-1 align-self-end">
                        <button type="submit" class="btn btn-primary btn-block">Tambah</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    
    <div class="card mb-4">
        <div class="card-header">Daftar Stok Toko</div>
        <div class="card-body table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Produk</th>
                        <th>Stok Sekarang</th>
                        <th>Log</th>
                        <th>Kurangi Stok</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($product->nama_barang); ?></td>
                        <td><?php echo e($product->stok); ?></td>
                        <td>
                            <ul>
                                <?php $__currentLoopData = $product->stokTokoLogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($log->tanggal); ?>: +<?php echo e($log->stok_masuk); ?> / -<?php echo e($log->stok_keluar); ?> (<?php echo e($log->keterangan); ?>)</li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </td>
                        <td>
                            
                            <form action="<?php echo e(route('stok-toko.update', $product->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="input-group">
                                    <input type="number" name="stok_keluar" class="form-control" min="1" max="<?php echo e($product->stok); ?>">
                                    <input type="text" name="keterangan" class="form-control" placeholder="Keterangan">
                                    <div class="input-group-append">
                                        <button type="submit" class="btn btn-danger btn-sm">Kurangi</button>
                                    </div>
                                </div>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if($products->isEmpty()): ?>
                    <tr>
                        <td colspan="4" class="text-center">Tidak ada data</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\sasalero-s\resources\views/stok_toko/index.blade.php ENDPATH**/ ?>