

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="mb-4">Manajemen Shift</h2>

    
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    
    <?php if(!$shiftAktif): ?>
        <div class="card mb-4">
            <div class="card-header">Buka Shift Baru</div>
            <div class="card-body">
                <form action="<?php echo e(route('shifts.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="modal_awal" class="form-label">Modal Awal</label>
                        <input type="number" step="0.01" name="modal_awal" id="modal_awal"
                               class="form-control <?php $__errorArgs = ['modal_awal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                        <?php $__errorArgs = ['modal_awal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <button type="submit" class="btn btn-primary">Buka Shift</button>
                </form>
            </div>
        </div>
    <?php else: ?>
        
        <div class="card mb-4">
            <div class="card-header">Shift Aktif</div>
            <div class="card-body">
                <p><strong>Tanggal:</strong> <?php echo e($shiftAktif->tanggal); ?></p>
                <p><strong>Jam Mulai:</strong> <?php echo e($shiftAktif->jam_mulai); ?></p>
                <p><strong>Modal Awal:</strong> Rp <?php echo e(number_format($shiftAktif->modal_awal, 0, ',', '.')); ?></p>

                
                <form action="<?php echo e(route('shifts.close', $shiftAktif->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="mb-3">
                        <label for="modal_akhir" class="form-label">Modal Akhir</label>
                        <input type="number" step="0.01" name="modal_akhir" id="modal_akhir"
                               class="form-control <?php $__errorArgs = ['modal_akhir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                        <?php $__errorArgs = ['modal_akhir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <button type="submit" class="btn btn-danger">Tutup Shift</button>
                </form>
            </div>
        </div>
    <?php endif; ?>

    
    <div class="card">
        <div class="card-header">Riwayat Shift</div>
        <div class="card-body">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>Tanggal</th>
                        <th>Kasir</th>
                        <th>Jam Mulai</th>
                        <th>Jam Selesai</th>
                        <th>Modal Awal</th>
                        <th>Modal Akhir</th>
                        <th>Total Penjualan</th>
                        <th>Total Pengeluaran</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $shifts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shift): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($shift->tanggal); ?></td>
                            <td><?php echo e($shift->user->name ?? '-'); ?></td>
                            <td><?php echo e($shift->jam_mulai); ?></td>
                            <td><?php echo e($shift->jam_selesai ?? '-'); ?></td>
                            <td>Rp <?php echo e(number_format($shift->modal_awal, 0, ',', '.')); ?></td>
                            <td><?php echo e($shift->modal_akhir ? 'Rp '.number_format($shift->modal_akhir, 0, ',', '.') : '-'); ?></td>
                            <td>Rp <?php echo e(number_format($shift->total_penjualan, 0, ',', '.')); ?></td>
                            <td>Rp <?php echo e(number_format($shift->expenses->sum('jumlah'), 0, ',', '.')); ?></td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-center">Belum ada data shift</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\sasalero-s\resources\views/shifts/index.blade.php ENDPATH**/ ?>