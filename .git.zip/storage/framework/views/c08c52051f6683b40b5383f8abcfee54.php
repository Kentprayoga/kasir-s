

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800">Stok Gudang</h1>

    
    <div class="card mb-4">
        <div class="card-header">Tambah Stok Gudang</div>
        <div class="card-body">
            <form action="<?php echo e(route('stok-gudang.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-row">
                    <div class="form-group col-md-4">
                        <label>Nama Barang</label>
                        <input type="text" name="nama_barang" class="form-control" required>
                    </div>
                    <div class="form-group col-md-3">
                        <label>Harga</label>
                        <input type="number" step="0.01" name="harga" class="form-control" required>
                    </div>
                    <div class="form-group col-md-3">
                        <label>Stok Awal</label>
                        <input type="number" name="stok_tersedia" class="form-control" required>
                    </div>
                    <div class="form-group col-md-2 align-self-end">
                        <button type="submit" class="btn btn-primary btn-block">Tambah</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    
    <div class="card mb-4">
        <div class="card-header">Daftar Stok Gudang</div>
        <div class="card-body table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Nama Barang</th>
                        <th>Harga</th>
                        <th>Stok Tersedia</th>
                        <th>Log</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $stokGudangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stok): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($stok->nama_barang); ?></td>
                        <td>Rp<?php echo e(number_format($stok->harga,0,',','.')); ?></td>
                        <td><?php echo e($stok->stok_tersedia); ?></td>
                        <td>
                            <ul>
                                <?php $__currentLoopData = $stok->logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($log->tanggal); ?>: +<?php echo e($log->stok_masuk); ?> / -<?php echo e($log->stok_keluar); ?> (<?php echo e($log->keterangan); ?>)</li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </td>
                        <td>
                            
                            <form action="<?php echo e(route('stok-gudang.update', $stok->id)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <div class="input-group">
                                    <input type="number" name="stok_tersedia" value="<?php echo e($stok->stok_tersedia); ?>" class="form-control" style="width:80px;">
                                    <input type="number" step="0.01" name="harga" value="<?php echo e($stok->harga); ?>" class="form-control" style="width:100px;">
                                    <div class="input-group-append">
                                        <button type="submit" class="btn btn-success btn-sm">Update</button>
                                    </div>
                                </div>
                            </form>
                            
                            <form action="<?php echo e(route('stok-gudang.destroy', $stok->id)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm mt-1">Hapus</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if($stokGudangs->isEmpty()): ?>
                    <tr>
                        <td colspan="5" class="text-center">Tidak ada data</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\sasalero-s\resources\views/stok_gudang/index.blade.php ENDPATH**/ ?>