

<?php $__env->startSection('content'); ?>

<div class="container">
    <h1>Riwayat Transaksi</h1>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Nomor Struk</th>
                <th>Tanggal</th>
                <th>Total</th>
                <th>Uang Dibayar</th>
                <th>Kembalian</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($t->nomor_struk); ?></td>
                <td><?php echo e(\Carbon\Carbon::parse($t->tanggal_transaksi)->format('d/m/Y H:i')); ?></td>
                <td>Rp<?php echo e(number_format($t->total,0,',','.')); ?></td>
                <td>Rp<?php echo e(number_format($t->uang_dibayar,0,',','.')); ?></td>
                <td>Rp<?php echo e(number_format($t->kembalian,0,',','.')); ?></td>
                <td>
                    <a href="<?php echo e(route('transactions.show', $t->id)); ?>" class="btn btn-primary btn-sm">Detail</a>
                    <a href="<?php echo e(route('transactions.receipt', $t->id)); ?>" class="btn btn-info btn-sm">Nota</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="6" class="text-center">Belum ada transaksi</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\sasalero-s\resources\views/transactions/index.blade.php ENDPATH**/ ?>