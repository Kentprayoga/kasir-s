

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Daftar Produk (Stok Toko)</h1>

    <a href="<?php echo e(route('products.create')); ?>" class="btn btn-primary mb-3">+ Tambah Produk</a>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Nama Barang</th>
                <th>Harga</th>
                <th>Stok</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($p->nama_barang); ?></td>
                <td>Rp<?php echo e(number_format($p->harga, 0, ',', '.')); ?></td>
                <td><?php echo e($p->stok); ?></td>
                <td>
                    <a href="<?php echo e(route('products.edit', $p->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                    <form action="<?php echo e(route('products.destroy', $p->id)); ?>" method="POST" class="d-inline"
                          onsubmit="return confirm('Yakin hapus produk ini?')">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-danger btn-sm">Hapus</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="4" class="text-center">Belum ada produk</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\sasalero-s\resources\views/products/index.blade.php ENDPATH**/ ?>