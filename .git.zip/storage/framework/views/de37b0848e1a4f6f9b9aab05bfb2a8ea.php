

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Buka Shift Baru</h2>

    <form action="<?php echo e(route('shifts.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="modal_awal">Modal Awal</label>
            <select name="modal_awal" id="modal_awal" class="form-control" required>
                <option value="">-- Pilih Modal Awal --</option>
                <option value="50000">Rp 50.000</option>
                <option value="100000">Rp 100.000</option>
                <option value="200000">Rp 200.000</option>
                <option value="500000">Rp 500.000</option>
                <option value="1000000">Rp 1.000.000</option>
            </select>
            <?php $__errorArgs = ['modal_awal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="text-danger"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <button type="submit" class="btn btn-primary mt-2">Buka Shift</button>
        <a href="<?php echo e(route('shifts.index')); ?>" class="btn btn-secondary mt-2">Batal</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\sasalero-s\resources\views/shifts/create.blade.php ENDPATH**/ ?>